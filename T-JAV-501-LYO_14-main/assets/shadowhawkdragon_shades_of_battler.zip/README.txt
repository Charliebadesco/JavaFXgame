Ce set de ressources a été ajouté sur Oniromancie le 12 mai 2023 et contient des monstres et des icônes formatées pour RPG Maker MV. 
Pour les battlers, il s'agit d'une sélection avec les versions statiques, mais il existe des versions animées et des fichiers annexes pour une compatibilité avec un plugin de Yanfly pour RPG Maker MZ.
Pour toute mise à jour, vous pouvez suivre l'actualité de l'auteur sur son site (https://shadowhawkdragon.wordpress.com).

Ces ressources sont maison, donc vous pouvez les utiliser sur d'autres supports que les logiciels mentionnés et les adapter à vos besoins.


Conditions d'utilisation :
- Gratuit pour un usage non commercial. Le crédit est apprécié, ne dites pas que c'est de vous.
- Gratuit pour un usage commercial, en échange de votre âme ! Je plaisante, un crédit et une notification avant la sortie sont tout ce que je demande...
- La diffusion de ces ressources dans leur version originale ou modifiée est autorisée, mais vous devez donner le lien vers mon site (https://shadowhawkdragon.wordpress.com).
- (Vous pouvez éditer ces ressources)

Pour créditer l'auteur, veuillez utiliser ShadowHawkDragon. Si vous souhaitez inclure son logo, vous devez le contacter.

Crédits supplémentaires : Les battlers mentionnés sont basés sur le design d'autres artistes (indiqués par un préfixe sur le nom du fichier). Merci de leur donner crédit pour leur travail, et de ne pas utiliser ces ressources pour un projet commercial sans leur demander d'abord, sauf indication contraire.

insiredtangle [Blog]
~préfixe: inspire-
~conditions: InspiredTangle m'a donné tous les droits sur mon travail et seule ma permission est requise. Je vous recommande quand même de créditer InspiredTangle pour les designs si vous les utilisez.

ShiroHaru99
~préfixe: shiro-
~conditions: à contacter pour un usage commercial.




Terms and Conditions:

    Free for non-commercial games. Credit is appreciated and please do not claim them as your own.
    Free for commercial use on the condition you sell me your soul! Scratch that, credit and prior notice is all that I ask…
    Sharing of these battlers and edits is allowed but please link back to this site.

For Credit please refer to me as ShadowHawkDragon, in the case you wish to include my logo all you have to is ask 😉

Additional Credits: Specified Battlers are based off designs by additional artists (Indicated by file-name prefix)
Please give credit where due and do not use commercially without first seeking their permission unless stated in their own terms and conditions.

insiredtangle [Blog]
~prefix: inspire-
~terms: InspiredTangle has given me full rights to my work and so only permission is required from me, ShadowHawkDragon. I would still recommend you credit InspiredTangle for the designs in case you use any of these works.

ShiroHaru99
~prefix: shiro-
~terms: contact for commercial use